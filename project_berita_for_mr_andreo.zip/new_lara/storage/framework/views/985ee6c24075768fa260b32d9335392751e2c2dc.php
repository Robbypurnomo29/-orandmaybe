<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">profile</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <h2><?php echo e($user); ?></h2> what are you want ? <br>
                    <hr>

                    <a  href="<?php echo e(url('/modifeprofile')); ?>">
                    <button class="btn btn-primary">change profile</button>
                     </a> 
                     <a  href="<?php echo e(url('/addpost')); ?>">
                     <button class="btn btn-primary">add new post</button>
                     </a>
                      
                     <a  href="<?php echo e(url('/post')); ?>">
                     <button class="btn btn-primary">show your post</button>
                     </a>

                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>