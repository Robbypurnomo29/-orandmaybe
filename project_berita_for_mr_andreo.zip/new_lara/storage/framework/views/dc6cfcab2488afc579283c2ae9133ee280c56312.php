<!DOCTYPE html>
<html>
<head>
	<title>home</title>
</head>
<body>

	<h1>ini home dari blog </h1>
	<hr>
	<?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $konten): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		
	<li><a href="blog/<?php echo e($konten -> id); ?>"><?php echo e($konten -> judul); ?></a></li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	
</body>
</html>