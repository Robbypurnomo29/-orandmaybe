<!DOCTYPE html>
<html>
<head>
	<title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
	<header>
		<nav>
			<a href="/home">home</a>
			<a href="/profiles">profiles</a>
		</nav>
	</header>
	<br>
	<?php echo $__env->yieldContent('content'); ?>
	<br>

	<footer>
		<p>
			&copyorandmaybe 2018
		</p>
	</footer>

</body>
</html>