<!DOCTYPE html>
<html>
<head>
	<title>home</title>
</head>
<body>
	<?php echo e($berita -> judul); ?>

	tag : <?php echo e($berita -> tag); ?>

	<hr>
	<?php echo e($berita -> isi); ?>

</body>
</html>