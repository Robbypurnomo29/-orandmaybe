<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">update post</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <form action="" method="post">
                        <label>judul</label><br>
                        <input type="text" value="<?php echo e($konten -> judul); ?> " name="judul"><br>
                        <label>tag</label><br>
                        <input type="text" value="<?php echo e($konten -> tag); ?>" name="tag"><br>
                        <label>isi</label><br>
                        <textarea rows="10" cols="50" name="isi"><?php echo e($konten -> isi); ?></textarea><br>
                        <?php echo e(csrf_field()); ?>

                        <input type="submit" name="submit" value="update" class="btn btn-primary">
                        
                        <input type="hidden" name="_method" value="PUT">
                        
                    </form>


                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>