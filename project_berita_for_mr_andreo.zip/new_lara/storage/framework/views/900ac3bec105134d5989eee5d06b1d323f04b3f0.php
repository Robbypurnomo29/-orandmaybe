<?php $__env->startSection('content'); ?>
	<h1>page home</h1>
	<?php if(isset($page)): ?>
		<?php echo e($page); ?>

	<?php endif; ?>
	

	<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li> <?php echo e($nama); ?> </li>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>