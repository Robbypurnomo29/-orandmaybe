<?php $__env->startSection('content'); ?>
	<h1>page home</h1>
	page <a href="home/1">1</a> <a href="home/2">2</a> <a href="home/3">3</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>