<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">create your post</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <form action="/home" method="post">
                        <label>judul</label><br>
                        <input type="text" value="" placeholder="judul" name="judul" ><br>
                        <label>tag</label><br>
                        <input type="text" value="" placeholder="tag" name="tag"><br>
                        <label>isi</label><br>
                        <textarea rows="10" cols="50" placeholder="Tulis berita anda disini...." name="isi"></textarea><br>
                        <?php echo e(csrf_field()); ?>

                        <input type="submit" name="submit" value="posting" class="btn btn-primary">
                    </form>


                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>