@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">home</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <p>your post</p>
                    @foreach ($konten as $kontens)
                   
                        <div>
                        <li><a href="home/{{$kontens -> id}}">{{ $kontens -> judul }}</a> <p>{{ $kontens -> created_at }} <a href="home/{{$kontens -> id}}/edit">edit</a> <a href="hapus">hapus</a></p></li> 
                        </div>
                    
                       
                    @endforeach


                    
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
