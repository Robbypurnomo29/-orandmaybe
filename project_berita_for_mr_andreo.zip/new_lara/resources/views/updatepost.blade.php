@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">update post</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    
                    <form action="" method="post">
                        <label>judul</label><br>
                        <input type="text" value="{{ $konten -> judul }} " name="judul"><br>
                        <label>tag</label><br>
                        <input type="text" value="{{ $konten -> tag }}" name="tag"><br>
                        <label>isi</label><br>
                        <textarea rows="10" cols="50" name="isi">{{ $konten -> isi }}</textarea><br>
                        {{ csrf_field() }}
                        <input type="submit" name="submit" value="update" class="btn btn-primary">
                        
                        <input type="hidden" name="_method" value="PUT">
                        
                    </form>


                    
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
