@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">create your post</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    
                    <form action="/home" method="post">
                        <label>judul</label><br>
                        <input type="text" value="" placeholder="judul" name="judul" ><br>
                        <label>tag</label><br>
                        <input type="text" value="" placeholder="tag" name="tag"><br>
                        <label>isi</label><br>
                        <textarea rows="10" cols="50" placeholder="Tulis berita anda disini...." name="isi"></textarea><br>
                        {{ csrf_field() }}
                        <input type="submit" name="submit" value="posting" class="btn btn-primary">
                    </form>


                    
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
