<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\berita;
use Auth;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $konten = berita::all();
        return view('home', ['konten' => $konten]);
    }

     public function show($id)
    {
        $konten = berita::find($id);
        return view('konten', ['konten' => $konten]);
    }

     public function update($id)
    {
        $konten = berita::find($id);
        return view('updatepost', ['konten' => $konten]);
    }

    public function edit(Request $request, $id)
    {
       $berita = berita::find($id);
       $berita -> judul = $request -> judul;
       $berita -> tag = $request -> tag;
       $berita -> isi = $request -> isi;
       $berita->save();
       redirect('/home/$id');
    }

   public function create()
   {
    return view('addpost');
   }

   public function profile()
   {
    $user = Auth::user()->name;
    return view('profile', ['user' => $user]);
   }

   public function store(request $request)
   {
        $berita = new berita;
        $berita -> judul = $request -> judul;
        $berita -> tag = $request -> tag;
        $berita -> isi = $request -> isi;
        $berita -> penulis = Auth::user()->name; 
        $berita -> save();

        return redirect('/home');

   }

   public function post()
   {
    $user = Auth::user()->name;
    $konten = berita::where('penulis', $user)->get();
   
    return view('post', ['user' => $user, 'konten' => $konten]);
   }

   public function cari(request $request, $mean)
   {
    $user = Auth::user()->name;
    $konten = berita::where('penulis', $user)->get();
    return view('cari', ['user' => $user, 'konten' => $konten]);
   }
}
