<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\berita;

class orandmaybe_controller extends Controller
{
    function index()
    {
    	
    	$hasil = berita::all();
    	$pengguna = DB::table('pengguna_tb')->get();
    	return view('blog/home', ['berita' => $hasil, 'users' => $pengguna]);
    }

    function show($id)
    {
    	
    	$berita = berita::find($id);
    	return view('blog/page', ['berita' => $berita]);
    }

    function profile()
    {
    	return view('profile');
    }

    function addpost()
    {
    	return view('addpost');
    }
}
