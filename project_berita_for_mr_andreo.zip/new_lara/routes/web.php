<?php


Auth::routes(); Route::get('/home', 'HomeController@index'); Route::get('/', 'HomeController@index');

route::get('/', function(){
	return view('welcome');
});
route::get('/home/{id}', 'HomeController@show');
route::get('/addpost', 'HomeController@create');
route::post('/home', 'HomeController@store');
route::get('/profile', 'HomeController@profile');
route::get('/post', 'HomeController@post');
route::get('/home/{id}/edit', 'HomeController@update');
route::put('/home/{id}', 'HomeController@edit');
route::get('/home?mean={mean}&submit=cari', 'HomeController@cari');





